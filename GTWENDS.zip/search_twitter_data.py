#!/usr/bin/python
import twitter
import sys
import time
import urllib

#GLOBALS
#Variables that contains the user credentials to access Twitter API
g_access_token = "108122421-w5ki42lidDDp3twyAjHqv71RM67Z1RuibwjejR3J"
g_access_token_secret = "eQlTb5JuZ4RXY3kRjbwN0uB259kfvH4raEziWr7Adu33t"
g_consumer_key = "wP4LZozGDvtn9rzymbyM9Dao2"
g_consumer_secret = "PdIAZ5CCVvccGm2qsNVr43VT165QMc3zyfsCdNLJHbwMzQz9Ky"

#silent print parameter
g_silent = False

#US geo box
g_geo = ['32.806671,-86.791130,232km', '61.370716,-152.404419,7250km',
         '33.729759,-111.431221,200km', '34.969704,-92.373123,120km',
         '36.116203,-119.681564,300km', '39.059811,-105.311104,km',
         '41.597782,-72.755371,160km', '39.318523,-75.507141,50km',
         '38.897438,-77.026817,5km', '27.766279,-81.686783,300km',
         '33.040619,-83.643074,150km', '21.094318,-157.498337,200km',
         '44.240459,-114.478828,180km', '40.349457,-88.986137,180km', #stopped here
         '39.849426,-86.258278,100km', '42.011539,-93.210526,100km',
         '38.526600,-96.726486,100km', '37.668140,-84.670067,100km',
         '31.169546,-91.867805,100km', '44.693947,-69.381927,100km',
         '39.063946,-76.802101,100km', '42.230171,-71.530106,100km',
         '43.326618,-84.536095,100km', '45.694454,-93.900192,100km',
         '32.741646,-89.678696,100km', '38.456085,-92.288368,100km',
         '46.921925,-110.454353,100km', '41.125370,-98.268082,100km',
         '38.313515,-117.055374,100km', '43.452492,-71.563896,100km',
         '40.298904,-74.521011,100km', '34.840515,-106.248482,100km',
         '42.165726,-74.948051,100km', '35.630066,-79.806419,100km',
         '47.528912,-99.784012,100km', '40.388783,-82.764915,100km',
         '35.565342,-96.928917,100km', '44.572021,-122.070938,100km',
         '40.590752,-77.209755,100km', '41.680893,-71.511780,100km',
         '33.856892,-80.945007,100km', '44.299782,-99.438828,100km',
         '35.747845,-86.692345,100km', '31.054487,-97.563461,100km',
         '40.150032,-111.862434,100km', '44.045876,-72.710686,100km',
         '37.769337,-78.169968,100km', '47.400902,-121.490494,100km',
         '38.491226,-80.954453,100km', '44.268543,-89.616508,100km',
         '42.755966,-107.302490,100km']
g_geo_names = ['AL', 'AK', 'AZ', 'AR', 'CA',
               'CO', 'CT', 'DE', 'DC', 'FL', 'GA',
               'HI', 'ID', 'IL', 'IN', 'IA',
               'KS', 'KY', 'LA', 'ME', 'MD',
               'MA', 'MI', 'MN', 'MS', 'MO',
               'MT', 'NE', 'NV', 'NH', 'NJ',
               'NM', 'NY', 'NC', 'ND', 'OH',
               'OK', 'OR', 'PA', 'RI', 'SC',
               'SD', 'TN', 'TX', 'UT', 'VT',
               'VA', 'WA', 'WV', 'WI', 'WY']

def _print(x):
    if g_silent == False:
        print x

if __name__ == "__main__":
    if len(sys.argv) == 1:
        print "Provide trends"
        sys.exit()

    if len(sys.argv) > 2:
        if sys.argv[2] == "-s":
            g_silent = True

    _print("connecting to Twitter using python-twitter...")
    api = twitter.Api(consumer_key = g_consumer_key,
                      consumer_secret = g_consumer_secret,
                      access_token_key = g_access_token,
                      access_token_secret = g_access_token_secret)

    date = time.strftime("%Y-%m-%d")
    trends = sys.argv[1].split('\n')
    for trend in trends:
        print trend
        data = ""
        for i in range(0, len(g_geo)):
            query = urllib.urlencode({'q': trend, 'since': date, 'geocode' : g_geo[i]})
            _print(query)

            limit_reached = True
            while limit_reached == True:
                time.sleep(3)
                print "retrieving " + g_geo_names[i] + " data..."
                try:
                    results = api.GetSearch(raw_query = query)
                    _print(results)
                    limit_reached = False
                except:
                    print "Twitter data limit reached. Waiting 1 min to continue"
                    limit_reached
                    time.sleep(60)
                    continue


            line = g_geo_names[i] + " " + str(len(results)) + "\n"
            data += line
        trend = trend.replace(" ", "_")
        trend = trend.replace("#", "")
        file_name = "./Twitter_Data/" + date + trend + ".txt"
        f = open(file_name, "w+")
        f.write(str(data))
        f.close()
