#!/usr/bin/python
import pytrends
from pytrends.request import TrendReq
import sys
import time

#credentials
g_username = "a179spring@gmail.com"
g_password = "179vagelis"

#silent print parameter
g_silent = False

def _print(x):
    if g_silent == False:
        print x

if __name__ == "__main__":
    if len(sys.argv) == 1:
        print "Provide trends"
        sys.exit()

    if len(sys.argv) > 2:
        if sys.argv[2] == "-s":
            g_silent = True

    _print("connecting to Google with pytrends...")
    pytrend = TrendReq(g_username, g_password)

    date = time.strftime("%Y-%m-%d")
    trends = sys.argv[1].split('\n')
    for trend in trends:
        print trend
        trend = trend.replace("#", "")
        data = ""
        try:
            pytrend.build_payload(kw_list=[str(trend)], geo='US')
            data = pytrend.interest_by_region(resolution="STATE")
        except:
            print "could not find results for trend"
        trend = trend.replace(" ", "_")
        file_name = "./Google_Data/" + date + trend + ".txt"
        f = open(file_name, "w+")
        f.write(str(data))
        f.close()

