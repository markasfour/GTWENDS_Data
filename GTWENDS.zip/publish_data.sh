#!/bin/bash

git add * 1> /dev/null 2> /dev/null 
git commit -m "publishing data" 1> /dev/null 2> /dev/null
git push -u origin master 1> /dev/null 2> /dev/null
