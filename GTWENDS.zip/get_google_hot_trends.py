#!/usr/bin/python
import bs4
import sys
import requests

g_hot_trends_url ="http://www.google.com/trends/hottrends/atom/hourly"
g_silent = False

def _print(x):
    if g_silent == False:
        print x

if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == "-s":
            g_silent = True

    _print("connecting to Google Hot Trends...")
    soup = bs4.BeautifulSoup(requests.get(g_hot_trends_url).text.replace("![CDATA[", ""), 'html.parser')
    for link in soup.find_all('a'):
        print(str(link.contents)[3:-2])

