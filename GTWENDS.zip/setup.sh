#!/bin/bash

sudo pip install tweepy
sudo pip install python-twitter
sudo pip install bs4

mkdir Google_Data
mkdir Twitter_Data

git init
touch .gitignore
echo get_google_hot_trends.py >> .gitignore
echo get_twitter_trends.py >> .gitignore
echo tweepy >> .gitignore
echo run.sh >> .gitignore
echo publish_data.sh >> .gitignore
echo search_google_data.py >> .gitignore
echo search_twitter_data.py >> .gitignore
echo setup.sh >> .gitignore
