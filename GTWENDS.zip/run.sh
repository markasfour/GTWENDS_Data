#!/bin/bash

echo "launched backend..."

while :
do
    ran=false
    hour=`date +%H`
    echo $hour
    if [ $hour != 06 ] && [ $hour != 19 ] 
    then
        echo "not time to run. Going to sleep..."
        sleep 1s
    elif [ $ran == false ]
    then
        echo "starting..."
        #get trends
        twitter_trends="$(./get_twitter_trends.py -s)"
        echo "got Twitter trends"
        google_trends="$(./get_google_hot_trends.py -s)"
        echo "got Google trends"

        DATE=`date +%Y-%m-%d`

        twitter_trends_file="./Twitter_Trends/"
        twitter_trends_file+=$DATE
        twitter_trends_file+="twitter.txt"

        google_trends_file="./Google_Trends/"
        google_trends_file+=$DATE
        google_trends_file+="google.txt"

        echo "${twitter_trends}" > $twitter_trends_file
        echo "${google_trends}" > $google_trends_file

        #search trends
        trends=$twitter_trends
        trends+=$google_trends
        #echo "getting Google data..."
        #./search_google_data.py "${trends}" -s
        echo "getting Twitter data..."
        ./search_twitter_data.py "${trends}" -s

        echo "publishing data..."
        ./publish_data.sh
        echo "finished. Going to sleep..."
        ran=true
        sleep 1h
    fi
done
