#!/usr/bin/python
import tweepy
import sys

#GLOBALS
#Variables that contains the user credentials to access Twitter API
g_access_token = "108122421-w5ki42lidDDp3twyAjHqv71RM67Z1RuibwjejR3J"
g_access_token_secret = "eQlTb5JuZ4RXY3kRjbwN0uB259kfvH4raEziWr7Adu33t"
g_consumer_key = "wP4LZozGDvtn9rzymbyM9Dao2"
g_consumer_secret = "PdIAZ5CCVvccGm2qsNVr43VT165QMc3zyfsCdNLJHbwMzQz9Ky"

#print out to console
g_silent = False

#USA place id
g_usa = 23424977

def _print(x):
    if g_silent == False:
        print x

if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == "-s":
            g_silent = True

    _print("connecting to Twitter...")
    auth = tweepy.OAuthHandler(g_consumer_key, g_consumer_secret)
    auth.set_access_token(g_access_token, g_access_token_secret)
    api = tweepy.API(auth)


    responses = api.trends_place(g_usa)
    for response in responses:
        start_date = response['as_of']
        for trending in response['trends']:
            if trending['promoted_content'] == None:
                print trending['name']
